import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Calendar, Users, Building2, Info, BookOpen, Hotel, Compass } from "lucide-react"

export default function EACDFM2027() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-8 sm:py-12 md:py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-2xl sm:text-3xl md:text-5xl font-bold mb-4 text-balance leading-tight">
            East Asia Core Doctoral Forum in Mathematics 2027
          </h1>
          <p className="text-base sm:text-lg md:text-xl font-medium opacity-90 mb-6">
            EACDFM 2027
          </p>
          <div className="flex flex-col items-center justify-center gap-3 sm:gap-4 mt-6 sm:mt-8 text-base sm:text-lg md:text-xl">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 shrink-0" />
              <span>January 11-14, 2027</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 shrink-0" />
              <span>
                <a 
                  href="https://www.tohoku.ac.jp" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:underline"
                >
                  Tohoku University
                </a>, Sendai, Japan
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 sm:py-12 space-y-6 sm:space-y-8 md:space-y-12">
        {/* Organizer Section */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <Building2 className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">Organizer</h2>
              </div>
              <p className="text-base sm:text-lg text-muted-foreground">
                Mathematical Institute, Tohoku University
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Organizing Committee */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <Users className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">Organizing Committee</h2>
              </div>
              <ul className="space-y-2 text-base sm:text-lg text-muted-foreground">
                <li>Fumihiko Nakano (Tohoku U.)</li>
                <li>Yoji Akama (Tohoku U.)</li>
                <li>Kentaro Fujie (Tohoku U.)</li>
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* Program Section */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">Program</h2>
              </div>
              <div className="bg-muted rounded-lg p-4 sm:p-6 text-center">
                <p className="text-base sm:text-lg text-muted-foreground">
                  The program will be announced later.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Venue Section */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">Venue</h2>
              </div>
              <div className="space-y-3 sm:space-y-4">
                <p className="text-base sm:text-lg text-muted-foreground">
                  Aoba Science Hall (building H-04), Aobayama campus,{" "}
                  <a 
                    href="https://www.tohoku.ac.jp" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    Tohoku University
                  </a>
                </p>
                <p className="text-sm sm:text-base text-muted-foreground">
                  <a 
                    href="https://www.tohoku.ac.jp/en/about/map_directions.html" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    Access
                  </a>
                  {" / "}
                  <a 
                    href="https://www.tohoku.ac.jp/japanese/profile/campus/01/aobayama/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    Campus Map
                  </a>
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Hotel Section */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <Hotel className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">Hotel</h2>
              </div>
              <p className="text-base sm:text-lg text-muted-foreground">
                <a 
                  href="https://www.bh-green.co.jp/mark/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Hotel Green Mark
                </a>
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Sightseeing Section */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <Compass className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">Sightseeing</h2>
              </div>
              <ul className="space-y-2 text-base sm:text-lg text-muted-foreground">
                <li>
                  <a 
                    href="https://www.archives.tohoku.ac.jp/luxun/cn/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    鲁迅和东北大学
                  </a>
                </li>
                <li>
                  <a 
                    href="https://visitmiyagi.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    Visit Miyagi
                  </a>
                </li>
                <li>
                  <a 
                    href="https://livejapan.com/en/in-tohoku/in-pref-miyagi/in-miyagi-suburbs/article-a3000317/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    Winter in Miyagi: 3 Days of Whisky, Oysters, Scenic Trails & Hot Springs
                  </a>
                </li>
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* About EACDFM */}
        <section>
          <Card>
            <CardContent className="p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <Info className="w-5 h-5 sm:w-6 sm:h-6 text-primary shrink-0" />
                <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-foreground leading-tight">About East Asia Core Doctoral Forum in Mathematics</h2>
              </div>
              <p className="text-base sm:text-lg text-muted-foreground">
                For more information about EACDFM and past EACDFM, please visit:
              </p>
              <p className="mt-3 sm:mt-4">
                <a 
                  href="https://sites.google.com/math.ntu.edu.tw/eacdfmncts/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline text-base sm:text-lg font-medium break-words"
                >
                  EACDFM Official Website (NCTS)
                </a>
              </p>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-6 sm:py-8 mt-8 sm:mt-12 px-4">
        <div className="container mx-auto text-center">
          <p className="text-base sm:text-lg font-semibold mb-2 text-balance">
            East Asia Core Doctoral Forum in Mathematics 2027
          </p>
          <p className="text-xs sm:text-sm opacity-80">
            Mathematical Institute, Tohoku University
          </p>
          <p className="text-xs sm:text-sm opacity-80 mt-3 sm:mt-4">
            © 2027 EACDFM Organizing Committee
          </p>
        </div>
      </footer>
    </div>
  )
}
